

import streamlit as st
import pandas as pd
from PIL import Image

# Load data (assuming data is stored in an Excel sheet)
@st.cache
def load_data(file_path):
    return pd.read_excel(file_path)

# Function to search for violation
def search_violation(plate, data):
    result = data[data['License Plate'].str.contains(plate, case=False)]
    return result

# Streamlit App
st.title("Vehicle Violation Search")

# Upload the Excel file containing violations data
uploaded_file = st.file_uploader("Choose an Excel file with violation data", type="xlsx")

if uploaded_file:
    # Load data
    data = load_data(uploaded_file)
    
    # Input for car plate
    plate_input = st.text_input("Enter your car plate letters")

    if plate_input:
        # Search for the plate in the data
        violations = search_violation(plate_input, data)

        if not violations.empty:
            # Display results
            st.write(f"Found {len(violations)} violation(s) for the car plate: {plate_input}")
            st.dataframe(violations[['License Plate', 'Time of Violation']])
            
            # Show the photo of the violation if available
            for _, row in violations.iterrows():
                st.write(f"Violation at {row['Time of Violation']}")
                img_path = row['Photo Path']  # Assuming 'Photo Path' column contains the path to the photo
                img = Image.open(img_path)
                st.image(img, caption=f"License Plate: {row['License Plate']}", use_column_width=True)
        else:
            st.warning("No violations found for this car plate.")

