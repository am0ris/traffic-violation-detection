

import os

def delete_txt_files(folder_path):
    try:
        # List all files in the folder
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            # Check if the file is a .txt file and is a file (not a directory)
            if filename.endswith('.jpg') and os.path.isfile(file_path):
                os.remove(file_path)
                print(f"Deleted: {file_path}")
        print("All .txt files have been deleted.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Example usage
folder_path = r"D:\projrct rowad\Train\labels\val"
delete_txt_files(folder_path)
